__ADTECH_CODE__ = "";
__theDocument = document;
__theWindow = window;
__bCodeFlushed = false;

function __flushCode() {
	if (!__bCodeFlushed) {
		var span = parent.document.createElement("SPAN");
		span.innerHTML = __ADTECH_CODE__;
		window.frameElement.parentNode.appendChild(span);
		__bCodeFlushed = true;
	}
}

if (typeof inFIF != "undefined") {
	document.write = function(str) {
		__ADTECH_CODE__ += str;
	};
	document.writeln = function(str) {
		document.write(str + "\n");
	};
	__theDocument = parent.document;
	__theWindow = parent;
}
document.write("<!DOCTYPE html>\n");
document.write("<html>\n");
document.write("	<head>\n");
document.write("		<meta charset=\"utf-8\" />\n");
document.write("		\n");

document.write("		<title>FINN - Torget har blitt gratis</title>\n");

document.write("		<style>\n");
document.write("#Banner-body {\n");
document.write("margin:0;\n");
document.write("padding:0;\n");
document.write("width: 100%;\n");
document.write("height: 225px;\n");
document.write("overflow: hidden;\n");
document.write("}\n");
document.write("#Banner {\n");
document.write("display: block;\n");
document.write("position: static;\n");
document.write("width: 100%;\n");
document.write("height: 225px;\n");
document.write("cursor: pointer;\n");
document.write("overflow: hidden;\n");
document.write("}\n");
document.write(".container {\n");
document.write("position: relative;\n");
document.write("width: 100%;\n");
document.write("height: 225px;\n");
document.write("overflow: hidden;\n");
document.write("max-width: 1024px;\n");
document.write("margin: 0 auto;\n");
document.write("background-image: url(http://finncdn.no/trafikk/test/ole/egenreklame/2/img/bg.jpg);\n");
document.write("background-size: cover;\n");
document.write("background-repeat: no-repeat;\n");
document.write("background-position: right 70% center;\n");
document.write("}\n");
document.write(".slide1 {\n");
document.write("position: absolute;\n");
document.write("top: -300px;\n");
document.write("left: 20px;\n");
document.write("width: 100%;\n");
document.write("max-width: 360px;\n");
document.write("height: 100%;\n");
document.write("margin: 0 auto 0 auto;\n");
document.write("background: url(http://finncdn.no/trafikk/test/ole/egenreklame/2/img/text1_2lines.png) no-repeat;\n");
document.write("background-size: 80% auto;\n");
document.write("-webkit-animation: text1-appear 7s 1s infinite alternate cubic-bezier(0.77, 0, 0.175, 1); /* Safari 4+ */\n");
document.write("/*border: 1px solid red;*/\n");
document.write("}\n");
document.write(".slide2 {\n");
document.write("position: absolute;\n");
document.write("left: 20px;\n");
document.write("bottom: -250px;\n");
document.write("width: 70%;\n");
document.write("max-width: 243px;\n");
document.write("height: 100%;\n");
document.write("margin: 0 auto;\n");
document.write("background: url(http://finncdn.no/trafikk/test/ole/egenreklame/2/img/text2.png) no-repeat;\n");
document.write("background-size: 90% auto;\n");
document.write("/*border: 1px solid green;	*/\n");
document.write("-webkit-animation: text2-appear 7s 1s infinite alternate cubic-bezier(0.77, 0, 0.175, 1); /* Safari 4+ */\n");
document.write("}\n");
document.write(".star-img {\n");
document.write("position: absolute;\n");
document.write("right: 110px;\n");
document.write("bottom: -310px;\n");
document.write("width: 25%;\n");
document.write("max-width: 150px;\n");
document.write("height: auto;\n");
document.write("-webkit-animation: star-appear 7s 1s infinite alternate cubic-bezier(0.77, 0, 0.175, 1); /* Safari 4+ */\n");
document.write("-moz-animation:    star-appear 7s 1s infinite forwards; /* Fx 5+ */\n");
document.write("-o-animation:      star-appear 7s 1s infinite forwards; /* Opera 12+ */\n");
document.write("animation:         star-appear 7s 1s infinite forwards; /* IE 10+ */\n");
document.write("-webkit-transition: all 0.3s 0.1s cubic-bezier(0.77, 0, 0.175, 1);\n");
document.write("transition: all 0.3s 0.1s cubic-bezier(0.77, 0, 0.175, 1);\n");
document.write("}\n");
document.write(".logo {\n");
document.write("position: absolute;\n");
document.write("bottom: 15px;\n");
document.write("right: 15px;\n");
document.write("max-width: 95px;\n");
document.write("}\n");
document.write("@media screen and (min-width: 590px) {\n");
document.write(".slide1 {\n");
document.write("max-width: 380px;\n");
document.write("left: 30px;\n");
document.write("}\n");
document.write(".slide2 {\n");
document.write("left: 30px;\n");
document.write("bottom: -250px;\n");
document.write("max-width: 280px;\n");
document.write("}\n");
document.write("}\n");
document.write("@media screen and (min-width: 720px)  {\n");
document.write(".star-img {\n");
document.write("max-width: 200px;\n");
document.write("right: 140px;\n");
document.write("}\n");
document.write("}\n");
document.write("@media screen and (min-width: 820px)  {\n");
document.write(".star-img {\n");
document.write("max-width: 230px;\n");
document.write("right: 200px;\n");
document.write("}\n");
document.write("}\n");
document.write("@-webkit-keyframes star-appear {\n");
document.write("0%, 60%   { bottom: -310px; }\n");
document.write("65%   { bottom: 0; }\n");
document.write("70%   { bottom: -20px; }\n");
document.write("100% { bottom: -20px; }\n");
document.write("}\n");
document.write("@-moz-keyframes star-appear {\n");
document.write("0%, 60%   { bottom: -310px; }\n");
document.write("65%   { bottom: 0; }\n");
document.write("70%   { bottom: -20px; }\n");
document.write("100% { bottom: -20px; }\n");
document.write("}\n");
document.write("@-o-keyframes star-appear {\n");
document.write("0%, 60%   { bottom: -310px; }\n");
document.write("65%   { bottom: 0; }\n");
document.write("70%   { bottom: -20px; }\n");
document.write("100% { bottom: -20px; }\n");
document.write("}\n");
document.write("@keyframes star-appear {\n");
document.write("0%, 60%   { bottom: -310px; }\n");
document.write("65%   { bottom: 0; }\n");
document.write("70%   { bottom: -20px; }\n");
document.write("100% { bottom: -20px; }\n");
document.write("}\n");
document.write("@-webkit-keyframes text1-appear{\n");
document.write("0%, 1%   { top: -300px; }\n");
document.write("10%   { top: 30px; }\n");
document.write("12%   { top: 20px; }\n");
document.write("100% { top: 20px; }\n");
document.write("}\n");
document.write("@-moz-keyframes text1-appear{\n");
document.write("0%, 1%   { top: -300px; }\n");
document.write("10%   { top: 30px; }\n");
document.write("12%   { top: 20px; }\n");
document.write("100% { top: 20px; }\n");
document.write("}\n");
document.write("@-o-keyframes text1-appear{\n");
document.write("0%, 1%   { top: -300px; }\n");
document.write("10%   { top: 30px; }\n");
document.write("12%   { top: 20px; }\n");
document.write("100% { top: 20px; }\n");
document.write("}\n");
document.write("@keyframes text1-appear{\n");
document.write("0%, 1%   { top: -300px; }\n");
document.write("10%   { top: 30px; }\n");
document.write("12%   { top: 20px; }\n");
document.write("100% { top: 20px; }\n");
document.write("}\n");
document.write("@-webkit-keyframes text2-appear{\n");
document.write("0%, 30%   { bottom: -250px; }\n");
document.write("40%   { bottom: -110px; }\n");
document.write("100% { bottom: -110px; }\n");
document.write("}\n");
document.write("@-moz-keyframes text2-appear{\n");
document.write("0%, 30%   { bottom: -250px; }\n");
document.write("40%   { bottom: -110px; }\n");
document.write("100% { bottom: -110px; }\n");
document.write("}\n");
document.write("@-o-keyframes text2-appear{\n");
document.write("0%, 30%   { bottom: -250px; }\n");
document.write("40%   { bottom: -110px; }\n");
document.write("100% { bottom: -110px; }\n");
document.write("}\n");
document.write("@keyframes text2-appear{\n");
document.write("0%, 30%   { bottom: -250px; }\n");
document.write("40%   { bottom: -110px; }\n");
document.write("100% { bottom: -110px; }\n");
document.write("}\n");
document.write("</style>\n");
document.write("	</head>\n");
document.write("	<body id=\"Banner-body\" >\n");
document.write("		<div id=\"Banner\" data-responsive=\"225h\" onclick=\"window.open(&quot;http://helios.finn.no/adlink|989|4527501|0|16|AdId=9434959;BnId=52;itime=408893930;nodecode=yes;link=&quot;+'http://www.finn.no/finn/torget/adinput/annonsetype/?WT.ac_id=FINN_Torget_gratis_responsivt','new_window');\">\n");
document.write("		\n");
document.write("			<div class=\"container\">\n");
document.write("				<div class=\"slide1\"></div>\n");
document.write("				<div class=\"slide2\"></div>\n");
document.write("				<img class=\"star-img\" src=\"http://finncdn.no/trafikk/test/ole/egenreklame/2/img/star.png\" >\n");
document.write("				<img class=\"logo\" src=\"http://finncdn.no/trafikk/test/ole/egenreklame/2/img/logo.png\">\n");
document.write("			</div>\n");
document.write("		</div>\n");
var toggler = setInterval(function(){
toggleClass()
}, 4000);
function toggleClass(){
__theDocument.getElementById("Banner").classList.toggle('state');
};
document.write("</body>\n");
document.write("</html>\n");
function cleanUp() {
 if (typeof __parent.swappedRefs4527501 == "undefined") {
   __parent.swappedRefs4527501 = new Array();
 }

 while (__parent.swappedRefs4527501.length > 0) {
   var ref = __parent.swappedRefs4527501.pop();
   if (ref != "swappedRefs4527501") {
     __parent[ref] = null;
   }
 }
}

if (typeof inFIF != "undefined" && inFIF == true) {
 __parent = window.parent;
 window.onunload = cleanUp;
 cleanUp();

 for (var ref in window) {
   if ((typeof __parent[ref] == "undefined" || __parent[ref] == null)
         && ref != "frameElement" && ref != "event" && ref != "swappedRefs4527501" && ref != "onunload") {
     try {__parent[ref] = window[ref]; __parent.swappedRefs4527501.push(ref);} catch (e) {}
  }
 }
}


if (typeof inFIF != "undefined" && inFIF) {
	__flushCode();
}

if (typeof inFIF != "undefined" && inFIF == true) {
try {parent.write = write;
} catch (e) {}try {parent.writeln = writeln;
} catch (e) {}try {parent.__flushCode = __flushCode;
} catch (e) {}try {parent.toggleClass = toggleClass;
} catch (e) {}}


setInterval("", 16);
